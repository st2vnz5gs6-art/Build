from __future__ import annotations

import sys
import json
import time
import uuid
import email
import socket
import asyncio
import inspect
import logging
import platform
import email.utils
from types import TracebackType
from random import random
from typing import (
    TYPE_CHECKING,
    Any,
    Dict,
    List,
    Type,
    Tuple,
    Union,
    Generic,
    Mapping,
    TypeVar,
    Callable,
    Iterable,
    Iterator,
    Optional,
    Sequence,
    Generator,
    AsyncIterator,
    cast,
    overload,
)
from typing_extensions import Literal, override, get_origin

import anyio
import httpx2
import pydantic
from httpx2 import URL, Proxy, HTTPTransport, AsyncHTTPTransport
from pydantic import PrivateAttr
from opentelemetry import trace
from opentelemetry.trace import Tracer
from opentelemetry.util.types import AttributeValue

from . import _exceptions
from ._qs import Querystring
from ._files import to_httpx_files, async_to_httpx_files
from ._types import (
    Body,
    Omit,
    Query,
    Headers,
    Timeout,
    NotGiven,
    ResponseT,
    AnyMapping,
    PostParser,
    BinaryTypes,
    RequestFiles,
    HttpxSendArgs,
    RequestOptions,
    AsyncBinaryTypes,
    HttpxRequestFiles,
    ModelBuilderProtocol,
    OpenTelemetryClientOption,
    ResolvedOpenTelemetryOptions,
    omit,
    not_given,
)
from ._utils import (
    is_dict,
    is_list,
    asyncify,
    is_given,
    lru_cache,
    is_mapping,
    strip_omit,
    prepare_request_data,
    async_prepare_request_data,
)
from ._compat import PYDANTIC_V1, model_copy, model_dump
from ._models import GenericModel, FinalRequestOptions, validate_type, construct_type
from ._request import APIRequest
from ._tracing import (
    ApiCall,
    get_tracer,
    start_api_call_span,
    inject_trace_headers,
    remove_trace_headers,
    resolve_open_telemetry,
)
from ._response import (
    APIResponse,
    BaseAPIResponse,
    AsyncAPIResponse,
    extract_response_type,
)
from ._constants import (
    DEFAULT_TIMEOUT,
    MAX_RETRY_DELAY,
    DEFAULT_MAX_RETRIES,
    INITIAL_RETRY_DELAY,
    RAW_RESPONSE_HEADER,
    OVERRIDE_CAST_TO_HEADER,
    DEFAULT_CONNECTION_LIMITS,
)
from ._streaming import Stream, SSEDecoder, AsyncStream, SSEBytesDecoder
from ._exceptions import (
    AnthropicError,
    APIStatusError,
    RetryableError,
    APITimeoutError,
    APIConnectionError,
    APIResponseValidationError,
)
from ._middleware import (
    CallNext,
    Middleware,
    AsyncCallNext,
    MiddlewareInput,
    MiddlewareCallable,
    AsyncMiddlewareCallable,
    validate_sync_middleware,
    validate_async_middleware,
)
from ._utils._json import openapi_dumps
from .lib._tracing import OpenTelemetryConfig, finish_api_call_span
from ._utils._httpx import get_environment_proxies

log: logging.Logger = logging.getLogger(__name__)

# TODO: make base page type vars covariant
SyncPageT = TypeVar("SyncPageT", bound="BaseSyncPage[Any]")
AsyncPageT = TypeVar("AsyncPageT", bound="BaseAsyncPage[Any]")


_T = TypeVar("_T")
_T_co = TypeVar("_T_co", covariant=True)

_StreamT = TypeVar("_StreamT", bound=Stream[Any])
_AsyncStreamT = TypeVar("_AsyncStreamT", bound=AsyncStream[Any])

if TYPE_CHECKING:
    from httpx2._config import (
        DEFAULT_TIMEOUT_CONFIG,  # pyright: ignore[reportPrivateImportUsage]
    )

    HTTPX_DEFAULT_TIMEOUT = DEFAULT_TIMEOUT_CONFIG
else:
    try:
        from httpx2._config import DEFAULT_TIMEOUT_CONFIG as HTTPX_DEFAULT_TIMEOUT
    except ImportError:
        # taken from https://github.com/encode/httpx/blob/3ba5fe0d7ac70222590e759c31442b1cab263791/httpx/_config.py#L366
        HTTPX_DEFAULT_TIMEOUT = Timeout(5.0)


def _reject_httpx_object(name: str, value: object) -> None:
    """`httpx` objects don't work with `httpx2`, and would otherwise fail deep inside a request."""
    for cls in type(value).__mro__:
        module = getattr(cls, "__module__", None)
        if isinstance(module, str) and module.partition(".")[0] == "httpx":
            raise TypeError(
                f"Invalid `{name}` argument; `httpx.{cls.__name__}` is from the `httpx` package, but this SDK uses `httpx2`. Use `httpx2.{cls.__name__}` instead."
            )


class PageInfo:
    """Stores the necessary information to build the request to retrieve the next page.

    Either `url` or `params` must be set.
    """

    url: URL | NotGiven
    params: Query | NotGiven
    json: Body | NotGiven

    @overload
    def __init__(
        self,
        *,
        url: URL,
    ) -> None: ...

    @overload
    def __init__(
        self,
        *,
        params: Query,
    ) -> None: ...

    @overload
    def __init__(
        self,
        *,
        json: Body,
    ) -> None: ...

    def __init__(
        self,
        *,
        url: URL | NotGiven = not_given,
        json: Body | NotGiven = not_given,
        params: Query | NotGiven = not_given,
    ) -> None:
        self.url = url
        self.json = json
        self.params = params

    @override
    def __repr__(self) -> str:
        if self.url:
            return f"{self.__class__.__name__}(url={self.url})"
        if self.json:
            return f"{self.__class__.__name__}(json={self.json})"
        return f"{self.__class__.__name__}(params={self.params})"


class BasePage(GenericModel, Generic[_T]):
    """
    Defines the core interface for pagination.

    Type Args:
        ModelT: The pydantic model that represents an item in the response.

    Methods:
        has_next_page(): Check if there is another page available
        next_page_info(): Get the necessary information to make a request for the next page
    """

    _options: FinalRequestOptions = PrivateAttr()
    _model: Type[_T] = PrivateAttr()

    def has_next_page(self) -> bool:
        items = self._get_page_items()
        if not items:
            return False
        return self.next_page_info() is not None

    def next_page_info(self) -> Optional[PageInfo]: ...

    def _get_page_items(self) -> Iterable[_T]:  # type: ignore[empty-body]
        ...

    def _params_from_url(self, url: URL) -> httpx2.QueryParams:
        # TODO: do we have to preprocess params here?
        return httpx2.QueryParams(cast(Any, self._options.params)).merge(url.params)

    def _info_to_options(self, info: PageInfo) -> FinalRequestOptions:
        options = model_copy(self._options)
        options._strip_raw_response_header()

        if not isinstance(info.params, NotGiven):
            options.params = {**options.params, **info.params}
            return options

        if not isinstance(info.url, NotGiven):
            params = self._params_from_url(info.url)
            url = info.url.copy_with(params=params)
            options.params = dict(url.params)
            options.url = str(url)
            return options

        if not isinstance(info.json, NotGiven):
            if not is_mapping(info.json):
                raise TypeError("Pagination is only supported with mappings")

            if not options.json_data:
                options.json_data = {**info.json}
            else:
                if not is_mapping(options.json_data):
                    raise TypeError("Pagination is only supported with mappings")

                options.json_data = {**options.json_data, **info.json}
            return options

        raise ValueError("Unexpected PageInfo state")


class BaseSyncPage(BasePage[_T], Generic[_T]):
    _client: SyncAPIClient = pydantic.PrivateAttr()

    def _set_private_attributes(
        self,
        client: SyncAPIClient,
        model: Type[_T],
        options: FinalRequestOptions,
    ) -> None:
        if (not PYDANTIC_V1) and getattr(self, "__pydantic_private__", None) is None:
            self.__pydantic_private__ = {}

        self._model = model
        self._client = client
        self._options = options

    # Pydantic uses a custom `__iter__` method to support casting BaseModels
    # to dictionaries. e.g. dict(model).
    # As we want to support `for item in page`, this is inherently incompatible
    # with the default pydantic behaviour. It is not possible to support both
    # use cases at once. Fortunately, this is not a big deal as all other pydantic
    # methods should continue to work as expected as there is an alternative method
    # to cast a model to a dictionary, model.dict(), which is used internally
    # by pydantic.
    def __iter__(self) -> Iterator[_T]:  # type: ignore
        for page in self.iter_pages():
            for item in page._get_page_items():
                yield item

    def iter_pages(self: SyncPageT) -> Iterator[SyncPageT]:
        page = self
        while True:
            yield page
            if page.has_next_page():
                page = page.get_next_page()
            else:
                return

    def get_next_page(self: SyncPageT) -> SyncPageT:
        info = self.next_page_info()
        if not info:
            raise RuntimeError(
                "No next page expected; please check `.has_next_page()` before calling `.get_next_page()`."
            )

        options = self._info_to_options(info)
        return self._client._request_api_list(self._model, page=self.__class__, options=options)


class AsyncPaginator(Generic[_T, AsyncPageT]):
    def __init__(
        self,
        client: AsyncAPIClient,
        options: FinalRequestOptions,
        page_cls: Type[AsyncPageT],
        model: Type[_T],
    ) -> None:
        self._model = model
        self._client = client
        self._options = options
        self._page_cls = page_cls

    def __await__(self) -> Generator[Any, None, AsyncPageT]:
        return self._get_page().__await__()

    async def _get_page(self) -> AsyncPageT:
        # the page sends its options again for the next page, so it has to keep the prepared ones
        self._options = options = await self._client._copy_and_prepare(self._options)

        def _parser(resp: AsyncPageT) -> AsyncPageT:
            resp._set_private_attributes(
                model=self._model,
                options=options,
                client=self._client,
            )
            return resp

        options.post_parser = _parser

        return await self._client.request(self._page_cls, options)

    async def __aiter__(self) -> AsyncIterator[_T]:
        # https://github.com/microsoft/pyright/issues/3464
        page = cast(
            AsyncPageT,
            await self,  # type: ignore
        )
        async for item in page:
            yield item


class BaseAsyncPage(BasePage[_T], Generic[_T]):
    _client: AsyncAPIClient = pydantic.PrivateAttr()

    def _set_private_attributes(
        self,
        model: Type[_T],
        client: AsyncAPIClient,
        options: FinalRequestOptions,
    ) -> None:
        if (not PYDANTIC_V1) and getattr(self, "__pydantic_private__", None) is None:
            self.__pydantic_private__ = {}

        self._model = model
        self._client = client
        self._options = options

    async def __aiter__(self) -> AsyncIterator[_T]:
        async for page in self.iter_pages():
            for item in page._get_page_items():
                yield item

    async def iter_pages(self: AsyncPageT) -> AsyncIterator[AsyncPageT]:
        page = self
        while True:
            yield page
            if page.has_next_page():
                page = await page.get_next_page()
            else:
                return

    async def get_next_page(self: AsyncPageT) -> AsyncPageT:
        info = self.next_page_info()
        if not info:
            raise RuntimeError(
                "No next page expected; please check `.has_next_page()` before calling `.get_next_page()`."
            )

        options = self._info_to_options(info)
        return await self._client._request_api_list(self._model, page=self.__class__, options=options)


_HttpxClientT = TypeVar("_HttpxClientT", bound=Union[httpx2.Client, httpx2.AsyncClient])
_DefaultStreamT = TypeVar("_DefaultStreamT", bound=Union[Stream[Any], AsyncStream[Any]])


class BaseClient(Generic[_HttpxClientT, _DefaultStreamT]):
    _client: _HttpxClientT
    _version: str
    _base_url: URL
    max_retries: int
    _timeout: Union[float, Timeout, None]
    _timeout_overridden: bool
    _strict_response_validation: bool
    _idempotency_header: str | None
    _default_stream_cls: type[_DefaultStreamT] | None = None
    _middleware: tuple[MiddlewareInput, ...]
    # Whether the API this client talks to holds message threads. `beta.messages.thread()` raises where it does not,
    # and `beta.messages.tool_runner()` sends the full history every turn.
    _supports_message_threads: bool = False
    _gen_ai_provider_name: str = "anthropic"
    _otel_platform: str | None = None

    def __init__(
        self,
        *,
        version: str,
        base_url: str | URL,
        _strict_response_validation: bool,
        max_retries: int = DEFAULT_MAX_RETRIES,
        timeout: float | Timeout | None = DEFAULT_TIMEOUT,
        open_telemetry: OpenTelemetryClientOption = None,
        custom_headers: Mapping[str, str] | None = None,
        custom_query: Mapping[str, object] | None = None,
        middleware: Sequence[MiddlewareInput] | None = None,
    ) -> None:
        _reject_httpx_object("timeout", timeout)

        self._version = version
        self._base_url = self._enforce_trailing_slash(URL(base_url))
        self.max_retries = max_retries
        self._timeout = timeout
        self._timeout_overridden = False
        self._set_open_telemetry(open_telemetry)
        self._custom_headers = custom_headers or {}
        self._custom_query = custom_query or {}
        self._strict_response_validation = _strict_response_validation
        self._idempotency_header = None
        self._platform: Platform | None = None
        self._middleware = tuple(middleware or ())

        if max_retries is None:  # pyright: ignore[reportUnnecessaryComparison]
            raise TypeError(
                "max_retries cannot be None. If you want to disable retries, pass `0`; if you want unlimited retries, pass a very high number; if you want the default behavior, pass `anthropic.DEFAULT_MAX_RETRIES`"
            )

    def _set_open_telemetry(self, open_telemetry: OpenTelemetryClientOption) -> None:
        """Sets this client's `open_telemetry` option, and has it get its tracer anew. Nothing else sets the option.

        The constructor calls this, and so does `copy`, on the client it made, with what `_copy_open_telemetry` gives.
        """
        # The environment is read here only. A copy of the client that is given no option has the resolved one.
        options = resolve_open_telemetry(open_telemetry)
        self._open_telemetry = options
        self._lazy_tracer: Tracer | None | NotGiven = not_given
        self._otel = OpenTelemetryConfig(
            options, provider_name=self._gen_ai_provider_name, platform=self._otel_platform
        )

    @property
    def _tracer(self) -> Tracer | None:
        """This client's tracer, or `None` when it has no spans.

        The client gets it when it first needs it, so constructing or copying a client calls nothing of OpenTelemetry.
        """
        if isinstance(self._lazy_tracer, NotGiven):
            self._lazy_tracer = get_tracer(self._open_telemetry, self._version, scope=self._otel.instrumentation_scope)
        return self._lazy_tracer

    def _copy_open_telemetry(self, open_telemetry: OpenTelemetryClientOption) -> OpenTelemetryClientOption:
        """The `open_telemetry` option of a copy of this client: the one given, or else, for `None`, this client's own.

        The one given replaces this client's whole option: nothing of this client's is merged into it. This client's
        own is resolved, so the environment variables do not apply to a copy.
        """
        return {**self._open_telemetry} if open_telemetry is None else open_telemetry

    @property
    def open_telemetry(self) -> ResolvedOpenTelemetryOptions:
        """This client's `open_telemetry` option, with `propagation` and every field of its `traces` set.

        The fields that the option given to the client left out have their defaults. A client that was given no option
        has what the environment variables said when it was constructed. A client that was given `False` has
        `{"traces": {"enabled": False, ...}}`. The value is a copy, so changing it does not change the client.

        `with_options` replaces the whole option, so a copy of the client that changes one field starts from this value:

        ```py
        client.with_options(open_telemetry={**client.open_telemetry, "conversation_id": "conv_123"})
        ```
        """
        return {**self._open_telemetry, "traces": {**self._open_telemetry["traces"]}}

    def _enforce_trailing_slash(self, url: URL) -> URL:
        if url.raw_path.endswith(b"/"):
            return url
        return url.copy_with(raw_path=url.raw_path + b"/")

    def _make_status_error_from_response(
        self,
        response: httpx2.Response,
    ) -> APIStatusError:
        if response.is_closed and not response.is_stream_consumed:
            # We can't read the response body as it has been closed
            # before it was read. This can happen if an event hook
            # raises a status error.
            body = None
            err_msg = f"Error code: {response.status_code}"
        else:
            err_text = response.text.strip()
            body = err_text

            try:
                body = json.loads(err_text)
                err_msg = f"Error code: {response.status_code} - {body}"
            except Exception:
                err_msg = err_text or f"Error code: {response.status_code}"

        return self._make_status_error(err_msg, body=body, response=response)

    def _make_status_error(
        self,
        err_msg: str,
        *,
        body: object,
        response: httpx2.Response,
    ) -> _exceptions.APIStatusError:
        raise NotImplementedError()

    def _build_headers(self, options: FinalRequestOptions, *, retries_taken: int = 0) -> httpx2.Headers:
        timeout = self.timeout if isinstance(options.timeout, NotGiven) else options.timeout
        read_timeout = timeout.read if isinstance(timeout, Timeout) else timeout
        idempotency_header = self._idempotency_header
        idempotency_key = options.idempotency_key

        # lowest precedence first; any of these can be overridden or `Omit`-ted by the layers after it
        headers, omitted = build_headers(
            {
                "x-stainless-timeout": str(options.timeout.read)
                if isinstance(options.timeout, Timeout)
                else str(options.timeout),
                "x-stainless-retry-count": str(retries_taken),
                **({"x-stainless-read-timeout": str(read_timeout)} if read_timeout is not None else {}),
                **({idempotency_header: idempotency_key} if idempotency_header and idempotency_key else {}),
                **self.default_headers,
            },
            # `default_headers` already includes these, but as a layer of their own they also
            # win over any default a subclass adds after spreading them in
            self._custom_headers,
            options.headers or {},
        )
        self._validate_headers(headers, omitted)

        return headers

    def _prepare_url(self, url: str) -> URL:
        """
        Merge a URL argument together with any 'base_url' on the client,
        to create the URL used for the outgoing request.
        """
        # Copied from httpx's `_merge_url` method.
        merge_url = URL(url)
        if merge_url.is_relative_url:
            merge_raw_path = self.base_url.raw_path + merge_url.raw_path.lstrip(b"/")
            return self.base_url.copy_with(raw_path=merge_raw_path)

        return merge_url

    def _make_sse_decoder(self) -> SSEDecoder | SSEBytesDecoder:
        return SSEDecoder()

    def _build_request(
        self,
        options: FinalRequestOptions,
        *,
        retries_taken: int = 0,
    ) -> httpx2.Request:
        _reject_httpx_object("timeout", options.timeout)

        if log.isEnabledFor(logging.DEBUG):
            log.debug(
                "Request options: %s",
                model_dump(
                    options,
                    exclude_unset=True,
                    # Pydantic v1's `.dict()` can't copy every value these fields may hold: some `content`
                    # types, and the `extra_body` of a GET, which is left unprepared (e.g. a generator).
                    exclude={
                        "content",
                        "extra_json",
                    }
                    if PYDANTIC_V1
                    else {},
                ),
            )
        kwargs: dict[str, Any] = {}

        json_data = options.json_data
        if options.extra_json is not None:
            if json_data is None:
                json_data = cast(Body, options.extra_json)
            elif is_mapping(json_data):
                json_data = _merge_mappings(json_data, options.extra_json)
            else:
                raise RuntimeError(f"Unexpected JSON data type, {type(json_data)}, cannot merge with `extra_body`")

        headers = self._build_headers(options, retries_taken=retries_taken)
        params = _merge_mappings(self.default_query, options.params)
        content_type = headers.get("Content-Type")
        files = options.files

        # If the given Content-Type header is multipart/form-data then it
        # has to be removed so that httpx can generate the header with
        # additional information for us as it has to be in this form
        # for the server to be able to correctly parse the request:
        # multipart/form-data; boundary=---abc--
        if content_type is not None and content_type.lower().startswith("multipart/form-data"):
            if "boundary" not in content_type.lower():
                # only remove the header if the boundary hasn't been explicitly set
                # as the caller doesn't want httpx to come up with their own boundary
                headers.pop("Content-Type")

            # As we are now sending multipart/form-data instead of application/json
            # we need to tell httpx to use it, https://httpx2.pydantic.dev/advanced/clients/#multipart-file-encoding
            if json_data:
                if not is_dict(json_data):
                    raise TypeError(
                        f"Expected query input to be a dictionary for multipart requests but got {type(json_data)} instead."
                    )
                kwargs["data"] = self._serialize_multipartform(json_data)

            # httpx determines whether or not to send a "multipart/form-data"
            # request based on the truthiness of the "files" argument.
            # This gets around that issue by generating a dict value that
            # evaluates to true.
            #
            # https://github.com/encode/httpx/discussions/2399#discussioncomment-3814186
            if not files:
                files = cast(HttpxRequestFiles, ForceMultipartDict())

        prepared_url = self._prepare_url(options.url)
        # preserve hard-coded query params from the url
        if params and prepared_url.query:
            params = {**dict(prepared_url.params.items()), **params}
            prepared_url = prepared_url.copy_with(raw_path=prepared_url.raw_path.split(b"?", 1)[0])
        if "_" in prepared_url.host:
            # work around https://github.com/encode/httpx/discussions/2880
            kwargs["extensions"] = {"sni_hostname": prepared_url.host.replace("_", "-")}

        is_body_allowed = options.method.lower() != "get"

        if is_body_allowed:
            if options.content is not None and json_data is not None:
                raise TypeError("Passing both `content` and `json_data` is not supported")
            if options.content is not None and files is not None:
                raise TypeError("Passing both `content` and `files` is not supported")
            if isinstance(json_data, bytes):
                raise TypeError("Passing raw bytes as `body` is not supported, pass them as `content` instead")
            if options.content is not None:
                kwargs["content"] = options.content
            elif not files:
                # Don't set content when JSON is sent as multipart/form-data,
                # since httpx's content param overrides other body arguments
                kwargs["content"] = openapi_dumps(json_data) if is_given(json_data) and json_data is not None else None
            kwargs["files"] = files
        else:
            headers.pop("Content-Type", None)
            kwargs.pop("data", None)

        # TODO: report this error to httpx
        return self._client.build_request(  # pyright: ignore[reportUnknownMemberType]
            headers=headers,
            timeout=self.timeout if isinstance(options.timeout, NotGiven) else options.timeout,
            method=options.method,
            url=prepared_url,
            # the `Query` type that we use is incompatible with qs'
            # `Params` type as it needs to be typed as `Mapping[str, object]`
            # so that passing a `TypedDict` doesn't cause an error.
            # https://github.com/microsoft/pyright/issues/3526#event-6715453066
            params=self.qs.stringify(cast(Mapping[str, Any], params)) if params else None,
            **kwargs,
        )

    def _serialize_multipartform(self, data: Mapping[object, object]) -> dict[str, object]:
        items = self.qs.stringify_items(
            # TODO: type ignore is required as stringify_items is well typed but we can't be
            # well typed without heavy validation.
            data,  # type: ignore
            array_format="brackets",
        )
        serialized: dict[str, object] = {}
        for key, value in items:
            existing = serialized.get(key)

            if existing is None:
                serialized[key] = value
                continue

            # If a value has already been set for this key then that
            # means we're sending data like `array[]=[1, 2, 3]` and we
            # need to tell httpx that we want to send multiple values with
            # the same key which is done by using a list or a tuple.
            #
            # Note: 2d arrays should never result in the same key at both
            # levels so it's safe to assume that if the value is a list,
            # it was because we changed it to be a list.
            if is_list(existing):
                existing.append(value)
            else:
                serialized[key] = [existing, value]

        return serialized

    def _maybe_override_cast_to(self, cast_to: type[ResponseT], options: FinalRequestOptions) -> type[ResponseT]:
        if not is_given(options.headers):
            return cast_to

        # make a copy of the headers so we don't mutate user-input
        headers = dict(options.headers)

        # we internally support defining a temporary header to override the
        # default `cast_to` type for use with `.with_raw_response` and `.with_streaming_response`
        # see _response.py for implementation details
        override_cast_to = headers.pop(OVERRIDE_CAST_TO_HEADER, not_given)
        if is_given(override_cast_to):
            options.headers = headers
            return cast(Type[ResponseT], override_cast_to)

        return cast_to

    def _should_stream_response_body(self, request: httpx2.Request) -> bool:
        return request.headers.get(RAW_RESPONSE_HEADER) == "stream"  # type: ignore[no-any-return]

    def _process_response_data(
        self,
        *,
        data: object,
        cast_to: type[ResponseT],
        response: httpx2.Response,
    ) -> ResponseT:
        if data is None:
            return cast(ResponseT, None)

        if cast_to is object:
            return cast(ResponseT, data)

        try:
            if inspect.isclass(cast_to) and issubclass(cast_to, ModelBuilderProtocol):
                return cast(ResponseT, cast_to.build(response=response, data=data))

            if self._strict_response_validation:
                return cast(ResponseT, validate_type(type_=cast_to, value=data))

            return cast(ResponseT, construct_type(type_=cast_to, value=data))
        except pydantic.ValidationError as err:
            raise APIResponseValidationError(response=response, body=data) from err

    @property
    def qs(self) -> Querystring:
        return Querystring()

    @property
    def custom_auth(self) -> httpx2.Auth | None:
        return None

    @property
    def auth_headers(self) -> dict[str, str]:
        return {}

    @property
    def default_headers(self) -> dict[str, str | Omit]:
        return {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "User-Agent": self.user_agent,
            **self.platform_headers(),
            **self.auth_headers,
            **self._custom_headers,
        }

    @property
    def default_query(self) -> dict[str, object]:
        return {
            **self._custom_query,
        }

    def _validate_headers(
        self,
        headers: httpx2.Headers,  # noqa: ARG002
        omitted: frozenset[str],  # noqa: ARG002
    ) -> None:
        """Validate the headers a request is about to be sent with.

        `omitted` holds the (lowercase) names a header layer explicitly removed with `Omit`.

        Does nothing by default.
        """
        return

    @property
    def user_agent(self) -> str:
        return f"{self.__class__.__name__}/Python {self._version}"

    @property
    def timeout(self) -> Union[float, Timeout, None]:
        return self._timeout

    @timeout.setter
    def timeout(self, timeout: Union[float, Timeout, None]) -> None:
        self._timeout = timeout
        self._timeout_overridden = True

    @property
    def base_url(self) -> URL:
        return self._base_url

    @base_url.setter
    def base_url(self, url: URL | str) -> None:
        self._base_url = self._enforce_trailing_slash(url if isinstance(url, URL) else URL(url))

    @property
    def middleware(self) -> tuple[MiddlewareInput, ...]:
        """The client-level middleware, outermost first.

        To run extra middleware for specific calls, derive a client with
        `client.with_options(middleware=[*client.middleware, extra])`.
        """
        return self._middleware

    def platform_headers(self) -> Dict[str, str]:
        # the actual implementation is in a separate `lru_cache` decorated
        # function because adding `lru_cache` to methods will leak memory
        # https://github.com/python/cpython/issues/88476
        return platform_headers(self._version, platform=self._platform)

    def _calculate_nonstreaming_timeout(self, max_tokens: int, max_nonstreaming_tokens: int | None) -> Timeout:
        maximum_time = 60 * 60
        default_time = 60 * 10

        expected_time = maximum_time * max_tokens / 128_000
        if expected_time > default_time or (max_nonstreaming_tokens and max_tokens > max_nonstreaming_tokens):
            raise ValueError(
                "Streaming is required for operations that may take longer than 10 minutes. "
                + "See https://platform.claude.com/docs/en/cli-sdks-libraries/sdks/python#long-requests for more details",
            )
        return Timeout(
            default_time,
            connect=5.0,
        )

    def _parse_retry_after_header(self, response_headers: Optional[httpx2.Headers] = None) -> float | None:
        """Returns a float of the number of seconds (not milliseconds) to wait after retrying, or None if unspecified.

        About the Retry-After header: https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Retry-After
        See also  https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Retry-After#syntax
        """
        if response_headers is None:
            return None

        # First, try the non-standard `retry-after-ms` header for milliseconds,
        # which is more precise than integer-seconds `retry-after`
        try:
            retry_ms_header = response_headers.get("retry-after-ms", None)
            return float(retry_ms_header) / 1000
        except (TypeError, ValueError):
            pass

        # Next, try parsing `retry-after` header as seconds (allowing nonstandard floats).
        retry_header = response_headers.get("retry-after")
        try:
            # note: the spec indicates that this should only ever be an integer
            # but if someone sends a float there's no reason for us to not respect it
            return float(retry_header)
        except (TypeError, ValueError):
            pass

        # Last, try parsing `retry-after` as a date.
        retry_date_tuple = email.utils.parsedate_tz(retry_header)
        if retry_date_tuple is None:
            return None

        retry_date = email.utils.mktime_tz(retry_date_tuple)
        return float(retry_date - time.time())

    def _calculate_retry_timeout(
        self,
        remaining_retries: int,
        options: FinalRequestOptions,
        response_headers: Optional[httpx2.Headers] = None,
    ) -> float:
        max_retries = options.get_max_retries(self.max_retries)

        # If the API asks us to wait a certain amount of time, just do what it says.
        retry_after = self._parse_retry_after_header(response_headers)
        if retry_after is not None and retry_after > 0:
            # `time.sleep` raises above a platform limit, as low as 2**32 milliseconds on Windows,
            # so wait at most that long.
            return min(retry_after, 4_294_967.0)

        # Also cap retry count to 1000 to avoid any potential overflows with `pow`
        nb_retries = min(max_retries - remaining_retries, 1000)

        # Apply exponential backoff, but not more than the max.
        sleep_seconds = min(INITIAL_RETRY_DELAY * pow(2.0, nb_retries), MAX_RETRY_DELAY)

        # Apply some jitter, plus-or-minus half a second.
        jitter = 1 - 0.25 * random()
        timeout = sleep_seconds * jitter
        return timeout if timeout >= 0 else 0

    def _should_retry(self, response: httpx2.Response) -> bool:
        # Note: this is not a standard header
        should_retry_header = response.headers.get("x-should-retry")

        # If the server explicitly says whether or not to retry, obey.
        if should_retry_header == "true":
            log.debug("Retrying as header `x-should-retry` is set to `true`")
            return True
        if should_retry_header == "false":
            log.debug("Not retrying as header `x-should-retry` is set to `false`")
            return False

        # Retry on request timeouts.
        if response.status_code == 408:
            log.debug("Retrying due to status code %i", response.status_code)
            return True

        # Retry on lock timeouts.
        if response.status_code == 409:
            log.debug("Retrying due to status code %i", response.status_code)
            return True

        # Retry on rate limits.
        if response.status_code == 429:
            log.debug("Retrying due to status code %i", response.status_code)
            return True

        # Retry internal errors.
        if response.status_code >= 500:
            log.debug("Retrying due to status code %i", response.status_code)
            return True

        log.debug("Not retrying")
        return False

    def _should_retry_exception(self, err: BaseException) -> tuple[bool, httpx2.Response | None]:
        """Whether an exception raised by a request attempt should be retried.

        Also returns the HTTP response behind the failure, when there is one, so
        retry timing can honor `retry-after` headers.

        Exceptions raised by middleware propagate to the caller as-is, except the
        ones that opt into the retry policy by type: `APIStatusError` (subject to
        the usual status-code policy), `APIConnectionError` / `APITimeoutError`,
        and `RetryableError`. The check walks each error's `__cause__` chain, so
        wrapping a retryable failure via `raise ... from err` preserves retries.
        """
        seen: set[int] = set()
        current: BaseException | None = err
        while current is not None and id(current) not in seen:
            seen.add(id(current))
            if isinstance(current, RetryableError):
                return True, None
            if isinstance(current, APIStatusError):
                return self._should_retry(current.response), current.response
            if isinstance(current, APIConnectionError):
                return True, None
            current = current.__cause__
        return False, None

    def _idempotency_key(self) -> str:
        return f"stainless-python-retry-{uuid.uuid4()}"


class _DefaultHttpxClient(httpx2.Client):
    def __init__(self, **kwargs: Any) -> None:
        _reject_httpx_object("transport", kwargs.get("transport"))
        kwargs.setdefault("timeout", DEFAULT_TIMEOUT)
        kwargs.setdefault("limits", DEFAULT_CONNECTION_LIMITS)
        kwargs.setdefault("follow_redirects", True)

        if "transport" not in kwargs:
            socket_options: List[Tuple[int, int, Union[int, bool]]] = [(socket.SOL_SOCKET, socket.SO_KEEPALIVE, True)]

            TCP_KEEPINTVL = getattr(socket, "TCP_KEEPINTVL", None)

            if TCP_KEEPINTVL is not None:
                socket_options.append((socket.IPPROTO_TCP, TCP_KEEPINTVL, 60))
            elif sys.platform == "darwin":
                TCP_KEEPALIVE = getattr(socket, "TCP_KEEPALIVE", 0x10)
                socket_options.append((socket.IPPROTO_TCP, TCP_KEEPALIVE, 60))

            TCP_KEEPCNT = getattr(socket, "TCP_KEEPCNT", None)
            if TCP_KEEPCNT is not None:
                socket_options.append((socket.IPPROTO_TCP, TCP_KEEPCNT, 5))

            TCP_KEEPIDLE = getattr(socket, "TCP_KEEPIDLE", None)
            if TCP_KEEPIDLE is not None:
                socket_options.append((socket.IPPROTO_TCP, TCP_KEEPIDLE, 60))

            proxy_map = {key: None if url is None else Proxy(url=url) for key, url in get_environment_proxies().items()}

            transport_kwargs = {
                arg: kwargs[arg] for arg in ("verify", "cert", "trust_env", "http1", "http2", "limits") if arg in kwargs
            }

            transport_kwargs["socket_options"] = socket_options

            proxy_mounts = {
                key: None if proxy is None else HTTPTransport(proxy=proxy, **transport_kwargs)
                for key, proxy in proxy_map.items()
            }
            default_transport = HTTPTransport(**transport_kwargs)

            # Prioritize the mounts set by the user over the environment variables.
            proxy_mounts.update(kwargs.get("mounts", {}))
            kwargs["mounts"] = proxy_mounts

            # Sets the default transport so that HTTPX won't automatically configure proxies.
            kwargs["transport"] = default_transport

        super().__init__(**kwargs)


if TYPE_CHECKING:
    DefaultHttpxClient = httpx2.Client
    """An alias to `httpx2.Client` that provides the same defaults that this SDK
    uses internally.

    This is useful because overriding the `http_client` with your own instance of
    `httpx2.Client` will result in httpx's defaults being used, not ours.
    """
else:
    DefaultHttpxClient = _DefaultHttpxClient


class SyncHttpxClientWrapper(DefaultHttpxClient):
    def __del__(self) -> None:
        if self.is_closed:
            return

        try:
            self.close()
        except Exception:
            pass


class SyncAPIClient(BaseClient[httpx2.Client, Stream[Any]]):
    _client: httpx2.Client
    _default_stream_cls: type[Stream[Any]] | None = None
    _middleware_chain: CallNext | None = None
    webhook_key: str | None = None

    def __init__(
        self,
        *,
        version: str,
        base_url: str | URL,
        max_retries: int = DEFAULT_MAX_RETRIES,
        timeout: float | Timeout | None | NotGiven = not_given,
        open_telemetry: OpenTelemetryClientOption = None,
        http_client: httpx2.Client | None = None,
        custom_headers: Mapping[str, str] | None = None,
        custom_query: Mapping[str, object] | None = None,
        middleware: Sequence[MiddlewareInput] | None = None,
        _strict_response_validation: bool,
    ) -> None:
        _reject_httpx_object("http_client", http_client)

        timeout_overridden = is_given(timeout)
        if not is_given(timeout):
            # if the user passed in a custom http client with a non-default
            # timeout set then we use that timeout.
            #
            # note: there is an edge case here where the user passes in a client
            # where they've explicitly set the timeout to match the default timeout
            # as this check is structural, meaning that we'll think they didn't
            # pass in a timeout and will ignore it
            if http_client and http_client.timeout != HTTPX_DEFAULT_TIMEOUT:
                timeout = http_client.timeout
                timeout_overridden = timeout != DEFAULT_TIMEOUT
            else:
                timeout = DEFAULT_TIMEOUT

        if http_client is not None and not isinstance(http_client, httpx2.Client):  # pyright: ignore[reportUnnecessaryIsInstance]
            raise TypeError(
                f"Invalid `http_client` argument; Expected an instance of `httpx2.Client` but got {type(http_client)}"
            )

        # materialize the middleware before validating it so that passing an
        # iterator/generator doesn't result in validation consuming it and the
        # middleware silently never running
        middleware = tuple(middleware or ())
        if middleware:
            validate_sync_middleware(middleware)

        super().__init__(
            version=version,
            # cast to a valid type because mypy doesn't understand our type narrowing
            timeout=cast(Timeout, timeout),
            open_telemetry=open_telemetry,
            base_url=base_url,
            max_retries=max_retries,
            custom_query=custom_query,
            custom_headers=custom_headers,
            middleware=middleware,
            _strict_response_validation=_strict_response_validation,
        )
        self._timeout_overridden = timeout_overridden
        self._middleware_chain = self._build_middleware_chain()
        self._client = http_client or SyncHttpxClientWrapper(
            base_url=base_url,
            # cast to a valid type because mypy doesn't understand our type narrowing
            timeout=cast(Timeout, timeout),
        )

    def is_closed(self) -> bool:
        return self._client.is_closed

    def close(self) -> None:
        """Close the underlying HTTPX client.

        The client will *not* be usable after this.
        """
        # If an error is thrown while constructing a client, self._client
        # may not be present
        if hasattr(self, "_client"):
            self._client.close()

    def __enter__(self: _T) -> _T:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        self.close()

    def _prepare_options(
        self,
        options: FinalRequestOptions,  # noqa: ARG002
    ) -> FinalRequestOptions:
        """Hook for mutating the given options"""
        return options

    def _prepare_request(
        self,
        request: httpx2.Request,  # noqa: ARG002
    ) -> None:
        """This method is used as a callback for mutating the `Request` object
        after it has been constructed.
        This is useful for cases where you want to add certain headers based off of
        the request properties, e.g. `url`, `method` etc.
        """
        return None

    @overload
    def request(
        self,
        cast_to: Type[ResponseT],
        options: FinalRequestOptions,
        *,
        stream: Literal[True],
        stream_cls: Type[_StreamT],
    ) -> _StreamT: ...

    @overload
    def request(
        self,
        cast_to: Type[ResponseT],
        options: FinalRequestOptions,
        *,
        stream: Literal[False] = False,
    ) -> ResponseT: ...

    @overload
    def request(
        self,
        cast_to: Type[ResponseT],
        options: FinalRequestOptions,
        *,
        stream: bool = False,
        stream_cls: Type[_StreamT] | None = None,
    ) -> ResponseT | _StreamT: ...

    def request(
        self,
        cast_to: Type[ResponseT],
        options: FinalRequestOptions,
        *,
        stream: bool = False,
        stream_cls: type[_StreamT] | None = None,
    ) -> ResponseT | _StreamT:
        # create a copy of the options we were given so that if the
        # options are mutated later & we then retry, the retries are
        # given the original options
        options = self._copy_and_prepare(options)
        if self._tracer is None:
            return self._request(cast_to, options, stream=stream, stream_cls=stream_cls)

        start_time = time.time_ns()
        propagation = self._open_telemetry["propagation"]
        span = start_api_call_span(
            self._tracer, self.base_url, options, self._otel.api_call_start_attributes(), propagation=propagation
        )
        if span is None:
            return self._request(cast_to, options, stream=stream, stream_cls=stream_cls)
        call = ApiCall(span, start_time, records_content=self._otel.records_content, propagation=propagation)
        try:
            with trace.use_span(span, end_on_exit=False, record_exception=False, set_status_on_exception=False):
                return self._request(cast_to, options, stream=stream, stream_cls=stream_cls, call=call)
        except BaseException as err:
            finish_api_call_span(self, span, call.result(options, error=err, cast_to=cast_to))
            raise

    def _request(
        self,
        cast_to: Type[ResponseT],
        options: FinalRequestOptions,
        *,
        stream: bool = False,
        stream_cls: type[_StreamT] | None = None,
        call: ApiCall | None = None,
    ) -> ResponseT | _StreamT:
        cast_to = self._maybe_override_cast_to(cast_to, options)

        input_options = options
        if input_options.idempotency_key is None and input_options.method.lower() != "get":
            # ensure the idempotency key is reused between requests
            input_options.idempotency_key = self._idempotency_key()

        # The prebuilt chain has no call to record its attempts on.
        chain = self._middleware_chain if call is None or not self._middleware else self._build_middleware_chain(call)
        max_retries = input_options.get_max_retries(self.max_retries)

        for retries_taken in range(max_retries + 1):
            remaining_retries = max_retries - retries_taken

            try:
                if chain is None:
                    response, prepared = self._attempt_request(
                        model_copy(input_options), stream=stream, retries_taken=retries_taken, call=call
                    )
                    if response.is_success:
                        result = self._process_response(
                            cast_to=cast_to,
                            options=prepared,
                            response=response,
                            stream=stream,
                            stream_cls=stream_cls,
                            retries_taken=retries_taken,
                        )
                        if call is not None:
                            call_result = call.result(options, response=response, data=result, cast_to=cast_to)
                            finish_api_call_span(self, call.span, call_result)
                        return result
                else:
                    request = APIRequest(
                        options=model_copy(input_options),
                        cast_to=cast_to,
                        stream=stream,
                        stream_cls=stream_cls,
                        retries_taken=retries_taken,
                    )
                    chain_result: Any = chain(request)
                    if not isinstance(chain_result, BaseAPIResponse) or chain_result.http_response.is_success:
                        value = self._finalize_middleware_result(chain_result, request)
                        if call is not None:
                            last_response = (
                                chain_result.http_response if isinstance(chain_result, BaseAPIResponse) else None
                            )
                            call_result = call.result(options, response=last_response, data=value, cast_to=cast_to)
                            finish_api_call_span(self, call.span, call_result)
                        return cast(Union[ResponseT, _StreamT], value)
                    response = chain_result.http_response
            except Exception as err:
                should_retry, failed_response = self._should_retry_exception(err)
                if remaining_retries <= 0 or not should_retry:
                    raise

                if failed_response is not None and not failed_response.is_closed:
                    failed_response.close()

                self._sleep_for_retry(
                    retries_taken=retries_taken,
                    max_retries=max_retries,
                    options=input_options,
                    response=failed_response,
                )
                continue

            # the attempt produced an error-status response — possibly inspected,
            # replaced or passed through by middleware
            if remaining_retries > 0 and self._should_retry(response):
                if not response.is_closed:
                    response.close()
                self._sleep_for_retry(
                    retries_taken=retries_taken,
                    max_retries=max_retries,
                    options=input_options,
                    response=response,
                )
                continue

            # If the response is streamed then we need to explicitly read the response
            # to completion before attempting to access the response text.
            if not response.is_closed:
                response.read()

            raise self._make_status_error_from_response(response) from None

        raise RuntimeError("could not resolve response (should never happen)")

    def _build_middleware_chain(self, call: ApiCall | None = None) -> CallNext | None:
        """Build the middleware invocation chain.

        The chain only depends on the immutable `self._middleware` tuple so it is built
        once at construction time. It is invoked once per HTTP attempt, inside the
        SDK's retry loop, with that attempt's `APIRequest`. A traced API call builds
        its own, whose attempts are recorded on `call`.
        """
        if not self._middleware:
            return None

        def base_handler(req: APIRequest) -> APIResponse[Any]:
            options = _prepare_middleware_options(req)
            response, prepared = self._attempt_request(
                options, stream=req.stream, retries_taken=req.retries_taken, call=call
            )
            return cast(
                "APIResponse[Any]",
                self._process_response(
                    cast_to=req.cast_to,
                    options=prepared,
                    response=response,
                    stream=req.stream,
                    stream_cls=req.stream_cls,
                    retries_taken=req.retries_taken,
                ),
            )

        def wrap(middleware: MiddlewareInput, call_next: CallNext) -> CallNext:
            handler = middleware.handle if isinstance(middleware, Middleware) else cast(MiddlewareCallable, middleware)

            def handle(req: APIRequest) -> APIResponse[Any]:
                return handler(req, call_next)

            return handle

        chain: CallNext = base_handler
        for entry in reversed(self._middleware):
            chain = wrap(entry, chain)
        return chain

    def _finalize_middleware_result(self, result: Any, request: APIRequest) -> Any:
        """Convert the `APIResponse` returned by the middleware chain into the value the original caller expects.

        The middleware chain operates on `APIResponse` objects; the original caller may
        have asked for a parsed model (the default) or for the `APIResponse` wrapper itself
        (`.with_raw_response` / `.with_streaming_response` / a `cast_to` that is itself a
        response class).
        """
        if not isinstance(result, BaseAPIResponse):
            # the middleware short-circuited with an already materialized value
            # (e.g. a cached model); hand it back verbatim
            return result
        response = cast("APIResponse[Any]", result)

        if _middleware_entry_mode(request) is not None:
            # the original caller expects the `APIResponse` wrapper itself
            return response

        if _expects_response_wrapper(request.cast_to):
            return response

        return response.parse()

    def _attempt_request(
        self,
        options: FinalRequestOptions,
        *,
        stream: bool = False,
        retries_taken: int = 0,
        call: ApiCall | None = None,
    ) -> tuple[httpx2.Response, FinalRequestOptions]:
        """Prepare, build and send a single HTTP attempt.

        Returns the response regardless of its status code, along with the prepared
        options it was sent with — status handling (the retry policy, raising typed
        errors for the caller) happens above, where middleware can inspect error
        responses first. Connection failures raise typed errors (`APITimeoutError`,
        `APIConnectionError`). `call`, an API call that has a span, records the attempt.
        """
        options = self._prepare_options(options)

        request = self._build_request(options, retries_taken=retries_taken)
        if call is not None and call.propagation:
            # `_prepare_request` may sign the headers, and `inject_trace_headers` sets these after it.
            remove_trace_headers(call.span, request.headers)
        self._prepare_request(request)

        kwargs: HttpxSendArgs = {}
        if self.custom_auth is not None:
            kwargs["auth"] = self.custom_auth

        if options.follow_redirects is not None:
            kwargs["follow_redirects"] = options.follow_redirects

        log.debug("Sending HTTP Request: %s %s", request.method, request.url)

        if call is not None:
            call.sending(request, options)
            if call.propagation:
                inject_trace_headers(call.span, request.headers)
        try:
            response = self._client.send(
                request,
                stream=stream or self._should_stream_response_body(request=request),
                **kwargs,
            )
        except httpx2.TimeoutException as err:
            log.debug("Encountered httpx2.TimeoutException", exc_info=True)
            raise APITimeoutError(request=request) from err
        except Exception as err:
            if isinstance(err, AnthropicError):
                # SDK-originated errors already carry their own type; don't wrap.
                raise

            log.debug("Encountered Exception", exc_info=True)
            raise APIConnectionError(request=request) from err

        log.debug(
            'HTTP Response: %s %s "%i %s" %s',
            request.method,
            request.url,
            response.status_code,
            response.reason_phrase,
            response.headers,
        )
        log.debug("request_id: %s", response.headers.get("request-id"))
        log.debug("workspace_id: %s", response.headers.get("anthropic-workspace-id"))

        return response, options

    def _copy_and_prepare(self, options: FinalRequestOptions) -> FinalRequestOptions:
        """A copy of `options` with `extra_body` merged into the body, and the body and query prepared.

        The data is walked once per request, before the retry loop, as it may hold one-shot iterators
        and file reads, which a retry cannot repeat. A GET sends no body, so its data is not read at all.
        """
        options = model_copy(options)
        if options.method.lower() != "get":
            _merge_extra_json(options)
            options.json_data = prepare_request_data(options.json_data, location="body")

        if options.params:
            options.params = prepare_request_data(options.params, location="query", keep_top_level_omit=True)

        return options

    def _sleep_for_retry(
        self, *, retries_taken: int, max_retries: int, options: FinalRequestOptions, response: httpx2.Response | None
    ) -> None:
        remaining_retries = max_retries - retries_taken
        if remaining_retries == 1:
            log.debug("1 retry left")
        else:
            log.debug("%i retries left", remaining_retries)

        timeout = self._calculate_retry_timeout(remaining_retries, options, response.headers if response else None)
        log.info("Retrying request to %s in %f seconds", options.url, timeout)

        time.sleep(timeout)

    def _process_response(
        self,
        *,
        cast_to: Type[ResponseT],
        options: FinalRequestOptions,
        response: httpx2.Response,
        stream: bool,
        stream_cls: type[Stream[Any]] | type[AsyncStream[Any]] | None,
        retries_taken: int = 0,
    ) -> ResponseT:
        origin = get_origin(cast_to) or cast_to

        if (
            inspect.isclass(origin)
            and issubclass(origin, BaseAPIResponse)
            # we only want to actually return the custom BaseAPIResponse class if we're
            # returning the raw response, or if we're not streaming SSE, as if we're streaming
            # SSE then `cast_to` doesn't actively reflect the type we need to parse into
            and (not stream or bool(response.request.headers.get(RAW_RESPONSE_HEADER)))
        ):
            if not issubclass(origin, APIResponse):
                raise TypeError(f"API Response types must subclass {APIResponse}; Received {origin}")

            response_cls = cast("type[BaseAPIResponse[Any]]", cast_to)
            return cast(
                ResponseT,
                response_cls(
                    raw=response,
                    client=self,
                    cast_to=extract_response_type(response_cls),
                    stream=stream,
                    stream_cls=stream_cls,
                    options=options,
                    retries_taken=retries_taken,
                ),
            )

        if cast_to == httpx2.Response:
            return cast(ResponseT, response)

        api_response = APIResponse(
            raw=response,
            client=self,
            cast_to=cast("type[ResponseT]", cast_to),  # pyright: ignore[reportUnnecessaryCast]
            stream=stream,
            stream_cls=stream_cls,
            options=options,
            retries_taken=retries_taken,
        )
        if bool(response.request.headers.get(RAW_RESPONSE_HEADER)):
            return cast(ResponseT, api_response)

        return api_response.parse()

    def _request_api_list(
        self,
        model: Type[object],
        page: Type[SyncPageT],
        options: FinalRequestOptions,
    ) -> SyncPageT:
        # the page sends its options again for the next page, so it has to keep the prepared ones
        options = self._copy_and_prepare(options)

        def _parser(resp: SyncPageT) -> SyncPageT:
            resp._set_private_attributes(
                client=self,
                model=model,
                options=options,
            )
            return resp

        options.post_parser = _parser

        return self.request(page, options, stream=False)

    @overload
    def get(
        self,
        path: str,
        *,
        cast_to: Type[ResponseT],
        options: RequestOptions = {},
        stream: Literal[False] = False,
    ) -> ResponseT: ...

    @overload
    def get(
        self,
        path: str,
        *,
        cast_to: Type[ResponseT],
        options: RequestOptions = {},
        stream: Literal[True],
        stream_cls: type[_StreamT],
    ) -> _StreamT: ...

    @overload
    def get(
        self,
        path: str,
        *,
        cast_to: Type[ResponseT],
        options: RequestOptions = {},
        stream: bool,
        stream_cls: type[_StreamT] | None = None,
    ) -> ResponseT | _StreamT: ...

    def get(
        self,
        path: str,
        *,
        cast_to: Type[ResponseT],
        options: RequestOptions = {},
        stream: bool = False,
        stream_cls: type[_StreamT] | None = None,
    ) -> ResponseT | _StreamT:
        opts = FinalRequestOptions.construct(method="get", url=path, **options)
        # cast is required because mypy complains about returning Any even though
        # it understands the type variables
        return cast(ResponseT, self.request(cast_to, opts, stream=stream, stream_cls=stream_cls))

    @overload
    def post(
        self,
        path: str,
        *,
        cast_to: Type[ResponseT],
        body: Body | None = None,
        content: BinaryTypes | None = None,
        options: RequestOptions = {},
        files: RequestFiles | None = None,
        stream: Literal[False] = False,
    ) -> ResponseT: ...

    @overload
    def post(
        self,
        path: str,
        *,
        cast_to: Type[ResponseT],
        body: Body | None = None,
        content: BinaryTypes | None = None,
        options: RequestOptions = {},
        files: RequestFiles | None = None,
        stream: Literal[True],
        stream_cls: type[_StreamT],
    ) -> _StreamT: ...

    @overload
    def post(
        self,
        path: str,
        *,
        cast_to: Type[ResponseT],
        body: Body | None = None,
        content: BinaryTypes | None = None,
        options: RequestOptions = {},
        files: RequestFiles | None = None,
        stream: bool,
        stream_cls: type[_StreamT] | None = None,
    ) -> ResponseT | _StreamT: ...

    def post(
        self,
        path: str,
        *,
        cast_to: Type[ResponseT],
        body: Body | None = None,
        content: BinaryTypes | None = None,
        options: RequestOptions = {},
        files: RequestFiles | None = None,
        stream: bool = False,
        stream_cls: type[_StreamT] | None = None,
    ) -> ResponseT | _StreamT:
        if body is not None and content is not None:
            raise TypeError("Passing both `body` and `content` is not supported")
        if files is not None and content is not None:
            raise TypeError("Passing both `files` and `content` is not supported")
        opts = FinalRequestOptions.construct(
            method="post", url=path, json_data=body, content=content, files=to_httpx_files(files), **options
        )
        return cast(ResponseT, self.request(cast_to, opts, stream=stream, stream_cls=stream_cls))

    def patch(
        self,
        path: str,
        *,
        cast_to: Type[ResponseT],
        body: Body | None = None,
        content: BinaryTypes | None = None,
        files: RequestFiles | None = None,
        options: RequestOptions = {},
    ) -> ResponseT:
        if body is not None and content is not None:
            raise TypeError("Passing both `body` and `content` is not supported")
        if files is not None and content is not None:
            raise TypeError("Passing both `files` and `content` is not supported")
        opts = FinalRequestOptions.construct(
            method="patch", url=path, json_data=body, content=content, files=to_httpx_files(files), **options
        )
        return self.request(cast_to, opts)

    def put(
        self,
        path: str,
        *,
        cast_to: Type[ResponseT],
        body: Body | None = None,
        content: BinaryTypes | None = None,
        files: RequestFiles | None = None,
        options: RequestOptions = {},
    ) -> ResponseT:
        if body is not None and content is not None:
            raise TypeError("Passing both `body` and `content` is not supported")
        if files is not None and content is not None:
            raise TypeError("Passing both `files` and `content` is not supported")
        opts = FinalRequestOptions.construct(
            method="put", url=path, json_data=body, content=content, files=to_httpx_files(files), **options
        )
        return self.request(cast_to, opts)

    def delete(
        self,
        path: str,
        *,
        cast_to: Type[ResponseT],
        body: Body | None = None,
        content: BinaryTypes | None = None,
        options: RequestOptions = {},
    ) -> ResponseT:
        if body is not None and content is not None:
            raise TypeError("Passing both `body` and `content` is not supported")
        opts = FinalRequestOptions.construct(method="delete", url=path, json_data=body, content=content, **options)
        return self.request(cast_to, opts)

    def get_api_list(
        self,
        path: str,
        *,
        model: Type[object],
        page: Type[SyncPageT],
        body: Body | None = None,
        options: RequestOptions = {},
        method: str = "get",
    ) -> SyncPageT:
        opts = FinalRequestOptions.construct(method=method, url=path, json_data=body, **options)
        return self._request_api_list(model, page, opts)


class _DefaultAsyncHttpxClient(httpx2.AsyncClient):
    def __init__(self, **kwargs: Any) -> None:
        _reject_httpx_object("transport", kwargs.get("transport"))
        kwargs.setdefault("timeout", DEFAULT_TIMEOUT)
        kwargs.setdefault("limits", DEFAULT_CONNECTION_LIMITS)
        kwargs.setdefault("follow_redirects", True)

        if "transport" not in kwargs:
            socket_options: List[Tuple[int, int, Union[int, bool]]] = [(socket.SOL_SOCKET, socket.SO_KEEPALIVE, True)]

            TCP_KEEPINTVL = getattr(socket, "TCP_KEEPINTVL", None)

            if TCP_KEEPINTVL is not None:
                socket_options.append((socket.IPPROTO_TCP, TCP_KEEPINTVL, 60))
            elif sys.platform == "darwin":
                TCP_KEEPALIVE = getattr(socket, "TCP_KEEPALIVE", 0x10)
                socket_options.append((socket.IPPROTO_TCP, TCP_KEEPALIVE, 60))

            TCP_KEEPCNT = getattr(socket, "TCP_KEEPCNT", None)
            if TCP_KEEPCNT is not None:
                socket_options.append((socket.IPPROTO_TCP, TCP_KEEPCNT, 5))

            TCP_KEEPIDLE = getattr(socket, "TCP_KEEPIDLE", None)
            if TCP_KEEPIDLE is not None:
                socket_options.append((socket.IPPROTO_TCP, TCP_KEEPIDLE, 60))

            proxy_map = {key: None if url is None else Proxy(url=url) for key, url in get_environment_proxies().items()}

            transport_kwargs = {
                arg: kwargs[arg] for arg in ("verify", "cert", "trust_env", "http1", "http2", "limits") if arg in kwargs
            }

            transport_kwargs["socket_options"] = socket_options

            proxy_mounts = {
                key: None if proxy is None else AsyncHTTPTransport(proxy=proxy, **transport_kwargs)
                for key, proxy in proxy_map.items()
            }
            default_transport = AsyncHTTPTransport(**transport_kwargs)

            # Prioritize the mounts set by the user over the environment variables.
            proxy_mounts.update(kwargs.get("mounts", {}))
            kwargs["mounts"] = proxy_mounts

            # Sets the default transport so that HTTPX won't automatically configure proxies.
            kwargs["transport"] = default_transport

        super().__init__(**kwargs)


try:
    from ._vendor import httpx_aiohttp
except (ImportError, AttributeError):

    class _DefaultAioHttpClient(httpx2.AsyncClient):
        def __init__(self, **_kwargs: Any) -> None:
            raise RuntimeError("To use the aiohttp client you must have installed the package with the `aiohttp` extra")
else:

    class _DefaultAioHttpClient(httpx_aiohttp.Httpx2AiohttpClient):  # type: ignore
        def __init__(self, **kwargs: Any) -> None:
            kwargs.setdefault("timeout", DEFAULT_TIMEOUT)
            kwargs.setdefault("limits", DEFAULT_CONNECTION_LIMITS)
            kwargs.setdefault("follow_redirects", True)

            super().__init__(**kwargs)


if TYPE_CHECKING:
    DefaultAsyncHttpxClient = httpx2.AsyncClient
    """An alias to `httpx2.AsyncClient` that provides the same defaults that this SDK
    uses internally.

    This is useful because overriding the `http_client` with your own instance of
    `httpx2.AsyncClient` will result in httpx's defaults being used, not ours.
    """

    DefaultAioHttpClient = httpx2.AsyncClient
    """An alias to `httpx2.AsyncClient` that changes the default HTTP transport to `aiohttp`."""
else:
    DefaultAsyncHttpxClient = _DefaultAsyncHttpxClient
    DefaultAioHttpClient = _DefaultAioHttpClient


class AsyncHttpxClientWrapper(DefaultAsyncHttpxClient):
    def __del__(self) -> None:
        if self.is_closed:
            return

        try:
            # TODO(someday): support non asyncio runtimes here
            asyncio.get_running_loop().create_task(self.aclose())
        except Exception:
            pass


class AsyncAPIClient(BaseClient[httpx2.AsyncClient, AsyncStream[Any]]):
    _client: httpx2.AsyncClient
    _default_stream_cls: type[AsyncStream[Any]] | None = None
    _middleware_chain: AsyncCallNext | None = None
    webhook_key: str | None = None

    def __init__(
        self,
        *,
        version: str,
        base_url: str | URL,
        _strict_response_validation: bool,
        max_retries: int = DEFAULT_MAX_RETRIES,
        timeout: float | Timeout | None | NotGiven = not_given,
        open_telemetry: OpenTelemetryClientOption = None,
        http_client: httpx2.AsyncClient | None = None,
        custom_headers: Mapping[str, str] | None = None,
        custom_query: Mapping[str, object] | None = None,
        middleware: Sequence[MiddlewareInput] | None = None,
    ) -> None:
        _reject_httpx_object("http_client", http_client)

        timeout_overridden = is_given(timeout)
        if not is_given(timeout):
            # if the user passed in a custom http client with a non-default
            # timeout set then we use that timeout.
            #
            # note: there is an edge case here where the user passes in a client
            # where they've explicitly set the timeout to match the default timeout
            # as this check is structural, meaning that we'll think they didn't
            # pass in a timeout and will ignore it
            if http_client and http_client.timeout != HTTPX_DEFAULT_TIMEOUT:
                timeout = http_client.timeout
                timeout_overridden = timeout != DEFAULT_TIMEOUT
            else:
                timeout = DEFAULT_TIMEOUT

        if http_client is not None and not isinstance(http_client, httpx2.AsyncClient):  # pyright: ignore[reportUnnecessaryIsInstance]
            raise TypeError(
                f"Invalid `http_client` argument; Expected an instance of `httpx2.AsyncClient` but got {type(http_client)}"
            )

        # materialize the middleware before validating it so that passing an
        # iterator/generator doesn't result in validation consuming it and the
        # middleware silently never running
        middleware = tuple(middleware or ())
        if middleware:
            validate_async_middleware(middleware)

        super().__init__(
            version=version,
            base_url=base_url,
            # cast to a valid type because mypy doesn't understand our type narrowing
            timeout=cast(Timeout, timeout),
            open_telemetry=open_telemetry,
            max_retries=max_retries,
            custom_query=custom_query,
            custom_headers=custom_headers,
            middleware=middleware,
            _strict_response_validation=_strict_response_validation,
        )
        self._timeout_overridden = timeout_overridden
        self._middleware_chain = self._build_middleware_chain()
        self._client = http_client or AsyncHttpxClientWrapper(
            base_url=base_url,
            # cast to a valid type because mypy doesn't understand our type narrowing
            timeout=cast(Timeout, timeout),
        )

    def is_closed(self) -> bool:
        return self._client.is_closed

    async def close(self) -> None:
        """Close the underlying HTTPX client.

        The client will *not* be usable after this.
        """
        await self._client.aclose()

    async def __aenter__(self: _T) -> _T:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        await self.close()

    async def _prepare_options(
        self,
        options: FinalRequestOptions,  # noqa: ARG002
    ) -> FinalRequestOptions:
        """Hook for mutating the given options"""
        return options

    async def _prepare_request(
        self,
        request: httpx2.Request,  # noqa: ARG002
    ) -> None:
        """This method is used as a callback for mutating the `Request` object
        after it has been constructed.
        This is useful for cases where you want to add certain headers based off of
        the request properties, e.g. `url`, `method` etc.
        """
        return None

    @overload
    async def request(
        self,
        cast_to: Type[ResponseT],
        options: FinalRequestOptions,
        *,
        stream: Literal[False] = False,
    ) -> ResponseT: ...

    @overload
    async def request(
        self,
        cast_to: Type[ResponseT],
        options: FinalRequestOptions,
        *,
        stream: Literal[True],
        stream_cls: type[_AsyncStreamT],
    ) -> _AsyncStreamT: ...

    @overload
    async def request(
        self,
        cast_to: Type[ResponseT],
        options: FinalRequestOptions,
        *,
        stream: bool,
        stream_cls: type[_AsyncStreamT] | None = None,
    ) -> ResponseT | _AsyncStreamT: ...

    async def request(
        self,
        cast_to: Type[ResponseT],
        options: FinalRequestOptions,
        *,
        stream: bool = False,
        stream_cls: type[_AsyncStreamT] | None = None,
    ) -> ResponseT | _AsyncStreamT:
        if self._platform is None:
            # `get_platform()` may block (e.g. `platform.uname()` runs a WMI query on Windows),
            # so resolve it in a worker thread rather than on the event loop
            self._platform = await asyncify(get_platform)()

        # create a copy of the options we were given so that if the
        # options are mutated later & we then retry, the retries are
        # given the original options
        options = await self._copy_and_prepare(options)
        if self._tracer is None:
            return await self._request(cast_to, options, stream=stream, stream_cls=stream_cls)

        start_time = time.time_ns()
        propagation = self._open_telemetry["propagation"]
        span = start_api_call_span(
            self._tracer, self.base_url, options, self._otel.api_call_start_attributes(), propagation=propagation
        )
        if span is None:
            return await self._request(cast_to, options, stream=stream, stream_cls=stream_cls)
        call = ApiCall(span, start_time, records_content=self._otel.records_content, propagation=propagation)
        try:
            with trace.use_span(span, end_on_exit=False, record_exception=False, set_status_on_exception=False):
                return await self._request(cast_to, options, stream=stream, stream_cls=stream_cls, call=call)
        except BaseException as err:
            finish_api_call_span(self, span, call.result(options, error=err, cast_to=cast_to))
            raise

    async def _request(
        self,
        cast_to: Type[ResponseT],
        options: FinalRequestOptions,
        *,
        stream: bool = False,
        stream_cls: type[_AsyncStreamT] | None = None,
        call: ApiCall | None = None,
    ) -> ResponseT | _AsyncStreamT:
        cast_to = self._maybe_override_cast_to(cast_to, options)

        input_options = options
        if input_options.idempotency_key is None and input_options.method.lower() != "get":
            # ensure the idempotency key is reused between requests
            input_options.idempotency_key = self._idempotency_key()

        # The prebuilt chain has no call to record its attempts on.
        chain = self._middleware_chain if call is None or not self._middleware else self._build_middleware_chain(call)
        max_retries = input_options.get_max_retries(self.max_retries)

        for retries_taken in range(max_retries + 1):
            remaining_retries = max_retries - retries_taken

            try:
                if chain is None:
                    response, prepared = await self._attempt_request(
                        model_copy(input_options), stream=stream, retries_taken=retries_taken, call=call
                    )
                    if response.is_success:
                        result = await self._process_response(
                            cast_to=cast_to,
                            options=prepared,
                            response=response,
                            stream=stream,
                            stream_cls=stream_cls,
                            retries_taken=retries_taken,
                        )
                        if call is not None:
                            call_result = call.result(options, response=response, data=result, cast_to=cast_to)
                            finish_api_call_span(self, call.span, call_result)
                        return result
                else:
                    request = APIRequest(
                        options=model_copy(input_options),
                        cast_to=cast_to,
                        stream=stream,
                        stream_cls=stream_cls,
                        retries_taken=retries_taken,
                    )
                    chain_result: Any = await chain(request)
                    if not isinstance(chain_result, BaseAPIResponse) or chain_result.http_response.is_success:
                        value = await self._finalize_middleware_result(chain_result, request)
                        if call is not None:
                            last_response = (
                                chain_result.http_response if isinstance(chain_result, BaseAPIResponse) else None
                            )
                            call_result = call.result(options, response=last_response, data=value, cast_to=cast_to)
                            finish_api_call_span(self, call.span, call_result)
                        return cast(Union[ResponseT, _AsyncStreamT], value)
                    response = chain_result.http_response
            except Exception as err:
                should_retry, failed_response = self._should_retry_exception(err)
                if remaining_retries <= 0 or not should_retry:
                    raise

                if failed_response is not None and not failed_response.is_closed:
                    await failed_response.aclose()

                await self._sleep_for_retry(
                    retries_taken=retries_taken,
                    max_retries=max_retries,
                    options=input_options,
                    response=failed_response,
                )
                continue

            # the attempt produced an error-status response — possibly inspected,
            # replaced or passed through by middleware
            if remaining_retries > 0 and self._should_retry(response):
                if not response.is_closed:
                    await response.aclose()
                await self._sleep_for_retry(
                    retries_taken=retries_taken,
                    max_retries=max_retries,
                    options=input_options,
                    response=response,
                )
                continue

            # If the response is streamed then we need to explicitly read the response
            # to completion before attempting to access the response text.
            if not response.is_closed:
                await response.aread()

            raise self._make_status_error_from_response(response) from None

        raise RuntimeError("could not resolve response (should never happen)")

    def _build_middleware_chain(self, call: ApiCall | None = None) -> AsyncCallNext | None:
        """Build the middleware invocation chain.

        The chain only depends on the immutable `self._middleware` tuple so it is built
        once at construction time. It is invoked once per HTTP attempt, inside the
        SDK's retry loop, with that attempt's `APIRequest`. A traced API call builds
        its own, whose attempts are recorded on `call`.
        """
        if not self._middleware:
            return None

        async def base_handler(req: APIRequest) -> AsyncAPIResponse[Any]:
            options = _prepare_middleware_options(req)
            response, prepared = await self._attempt_request(
                options, stream=req.stream, retries_taken=req.retries_taken, call=call
            )
            return cast(
                "AsyncAPIResponse[Any]",
                await self._process_response(
                    cast_to=req.cast_to,
                    options=prepared,
                    response=response,
                    stream=req.stream,
                    stream_cls=req.stream_cls,
                    retries_taken=req.retries_taken,
                ),
            )

        def wrap(middleware: MiddlewareInput, call_next: AsyncCallNext) -> AsyncCallNext:
            handler = (
                middleware.handle_async
                if isinstance(middleware, Middleware)
                else cast(AsyncMiddlewareCallable, middleware)
            )

            async def handle(req: APIRequest) -> AsyncAPIResponse[Any]:
                return await handler(req, call_next)

            return handle

        chain: AsyncCallNext = base_handler
        for entry in reversed(self._middleware):
            chain = wrap(entry, chain)
        return chain

    async def _finalize_middleware_result(self, result: Any, request: APIRequest) -> Any:
        """Convert the `AsyncAPIResponse` returned by the middleware chain into the value the original caller expects.

        The middleware chain operates on `AsyncAPIResponse` objects; the original caller
        may have asked for a parsed model (the default) or for the `AsyncAPIResponse` wrapper
        itself (`.with_raw_response` / `.with_streaming_response` / a `cast_to` that is itself
        a response class).
        """
        if not isinstance(result, BaseAPIResponse):
            # the middleware short-circuited with an already materialized value
            # (e.g. a cached model); hand it back verbatim
            return result
        response = cast("AsyncAPIResponse[Any]", result)

        if _middleware_entry_mode(request) is not None:
            # the original caller expects the `AsyncAPIResponse` wrapper itself
            return response

        if _expects_response_wrapper(request.cast_to):
            return response

        return await response.parse()

    async def _attempt_request(
        self,
        options: FinalRequestOptions,
        *,
        stream: bool = False,
        retries_taken: int = 0,
        call: ApiCall | None = None,
    ) -> tuple[httpx2.Response, FinalRequestOptions]:
        """Prepare, build and send a single HTTP attempt.

        Returns the response regardless of its status code, along with the prepared
        options it was sent with — status handling (the retry policy, raising typed
        errors for the caller) happens above, where middleware can inspect error
        responses first. Connection failures raise typed errors (`APITimeoutError`,
        `APIConnectionError`). `call`, an API call that has a span, records the attempt.
        """
        options = await self._prepare_options(options)

        request = self._build_request(options, retries_taken=retries_taken)
        if call is not None and call.propagation:
            # `_prepare_request` may sign the headers, and `inject_trace_headers` sets these after it.
            remove_trace_headers(call.span, request.headers)
        await self._prepare_request(request)

        kwargs: HttpxSendArgs = {}
        if self.custom_auth is not None:
            kwargs["auth"] = self.custom_auth

        if options.follow_redirects is not None:
            kwargs["follow_redirects"] = options.follow_redirects

        log.debug("Sending HTTP Request: %s %s", request.method, request.url)

        if call is not None:
            call.sending(request, options)
            if call.propagation:
                inject_trace_headers(call.span, request.headers)
        try:
            response = await self._client.send(
                request,
                stream=stream or self._should_stream_response_body(request=request),
                **kwargs,
            )
        except httpx2.TimeoutException as err:
            log.debug("Encountered httpx2.TimeoutException", exc_info=True)
            raise APITimeoutError(request=request) from err
        except Exception as err:
            if isinstance(err, AnthropicError):
                # SDK-originated errors already carry their own type; don't wrap.
                raise

            log.debug("Encountered Exception", exc_info=True)
            raise APIConnectionError(request=request) from err

        log.debug(
            'HTTP Response: %s %s "%i %s" %s',
            request.method,
            request.url,
            response.status_code,
            response.reason_phrase,
            response.headers,
        )
        log.debug("request_id: %s", response.headers.get("request-id"))
        log.debug("workspace_id: %s", response.headers.get("anthropic-workspace-id"))

        return response, options

    async def _copy_and_prepare(self, options: FinalRequestOptions) -> FinalRequestOptions:
        """A copy of `options` with `extra_body` merged into the body, and the body and query prepared.

        The data is walked once per request, before the retry loop, as it may hold one-shot iterators
        and file reads, which a retry cannot repeat. A GET sends no body, so its data is not read at all.
        """
        options = model_copy(options)
        if options.method.lower() != "get":
            _merge_extra_json(options)
            options.json_data = await async_prepare_request_data(options.json_data, location="body")

        if options.params:
            options.params = await async_prepare_request_data(
                options.params, location="query", keep_top_level_omit=True
            )

        return options

    async def _sleep_for_retry(
        self, *, retries_taken: int, max_retries: int, options: FinalRequestOptions, response: httpx2.Response | None
    ) -> None:
        remaining_retries = max_retries - retries_taken
        if remaining_retries == 1:
            log.debug("1 retry left")
        else:
            log.debug("%i retries left", remaining_retries)

        timeout = self._calculate_retry_timeout(remaining_retries, options, response.headers if response else None)
        log.info("Retrying request to %s in %f seconds", options.url, timeout)

        await anyio.sleep(timeout)

    async def _process_response(
        self,
        *,
        cast_to: Type[ResponseT],
        options: FinalRequestOptions,
        response: httpx2.Response,
        stream: bool,
        stream_cls: type[Stream[Any]] | type[AsyncStream[Any]] | None,
        retries_taken: int = 0,
    ) -> ResponseT:
        origin = get_origin(cast_to) or cast_to

        if (
            inspect.isclass(origin)
            and issubclass(origin, BaseAPIResponse)
            # we only want to actually return the custom BaseAPIResponse class if we're
            # returning the raw response, or if we're not streaming SSE, as if we're streaming
            # SSE then `cast_to` doesn't actively reflect the type we need to parse into
            and (not stream or bool(response.request.headers.get(RAW_RESPONSE_HEADER)))
        ):
            if not issubclass(origin, AsyncAPIResponse):
                raise TypeError(f"API Response types must subclass {AsyncAPIResponse}; Received {origin}")

            response_cls = cast("type[BaseAPIResponse[Any]]", cast_to)
            return cast(
                "ResponseT",
                response_cls(
                    raw=response,
                    client=self,
                    cast_to=extract_response_type(response_cls),
                    stream=stream,
                    stream_cls=stream_cls,
                    options=options,
                    retries_taken=retries_taken,
                ),
            )

        if cast_to == httpx2.Response:
            return cast(ResponseT, response)

        api_response = AsyncAPIResponse(
            raw=response,
            client=self,
            cast_to=cast("type[ResponseT]", cast_to),  # pyright: ignore[reportUnnecessaryCast]
            stream=stream,
            stream_cls=stream_cls,
            options=options,
            retries_taken=retries_taken,
        )
        if bool(response.request.headers.get(RAW_RESPONSE_HEADER)):
            return cast(ResponseT, api_response)

        return await api_response.parse()

    def _request_api_list(
        self,
        model: Type[_T],
        page: Type[AsyncPageT],
        options: FinalRequestOptions,
    ) -> AsyncPaginator[_T, AsyncPageT]:
        return AsyncPaginator(client=self, options=options, page_cls=page, model=model)

    @overload
    async def get(
        self,
        path: str,
        *,
        cast_to: Type[ResponseT],
        options: RequestOptions = {},
        stream: Literal[False] = False,
    ) -> ResponseT: ...

    @overload
    async def get(
        self,
        path: str,
        *,
        cast_to: Type[ResponseT],
        options: RequestOptions = {},
        stream: Literal[True],
        stream_cls: type[_AsyncStreamT],
    ) -> _AsyncStreamT: ...

    @overload
    async def get(
        self,
        path: str,
        *,
        cast_to: Type[ResponseT],
        options: RequestOptions = {},
        stream: bool,
        stream_cls: type[_AsyncStreamT] | None = None,
    ) -> ResponseT | _AsyncStreamT: ...

    async def get(
        self,
        path: str,
        *,
        cast_to: Type[ResponseT],
        options: RequestOptions = {},
        stream: bool = False,
        stream_cls: type[_AsyncStreamT] | None = None,
    ) -> ResponseT | _AsyncStreamT:
        opts = FinalRequestOptions.construct(method="get", url=path, **options)
        return await self.request(cast_to, opts, stream=stream, stream_cls=stream_cls)

    @overload
    async def post(
        self,
        path: str,
        *,
        cast_to: Type[ResponseT],
        body: Body | None = None,
        content: AsyncBinaryTypes | None = None,
        files: RequestFiles | None = None,
        options: RequestOptions = {},
        stream: Literal[False] = False,
    ) -> ResponseT: ...

    @overload
    async def post(
        self,
        path: str,
        *,
        cast_to: Type[ResponseT],
        body: Body | None = None,
        content: AsyncBinaryTypes | None = None,
        files: RequestFiles | None = None,
        options: RequestOptions = {},
        stream: Literal[True],
        stream_cls: type[_AsyncStreamT],
    ) -> _AsyncStreamT: ...

    @overload
    async def post(
        self,
        path: str,
        *,
        cast_to: Type[ResponseT],
        body: Body | None = None,
        content: AsyncBinaryTypes | None = None,
        files: RequestFiles | None = None,
        options: RequestOptions = {},
        stream: bool,
        stream_cls: type[_AsyncStreamT] | None = None,
    ) -> ResponseT | _AsyncStreamT: ...

    async def post(
        self,
        path: str,
        *,
        cast_to: Type[ResponseT],
        body: Body | None = None,
        content: AsyncBinaryTypes | None = None,
        files: RequestFiles | None = None,
        options: RequestOptions = {},
        stream: bool = False,
        stream_cls: type[_AsyncStreamT] | None = None,
    ) -> ResponseT | _AsyncStreamT:
        if body is not None and content is not None:
            raise TypeError("Passing both `body` and `content` is not supported")
        if files is not None and content is not None:
            raise TypeError("Passing both `files` and `content` is not supported")
        opts = FinalRequestOptions.construct(
            method="post", url=path, json_data=body, content=content, files=await async_to_httpx_files(files), **options
        )
        return await self.request(cast_to, opts, stream=stream, stream_cls=stream_cls)

    async def patch(
        self,
        path: str,
        *,
        cast_to: Type[ResponseT],
        body: Body | None = None,
        content: AsyncBinaryTypes | None = None,
        files: RequestFiles | None = None,
        options: RequestOptions = {},
    ) -> ResponseT:
        if body is not None and content is not None:
            raise TypeError("Passing both `body` and `content` is not supported")
        if files is not None and content is not None:
            raise TypeError("Passing both `files` and `content` is not supported")
        opts = FinalRequestOptions.construct(
            method="patch",
            url=path,
            json_data=body,
            content=content,
            files=await async_to_httpx_files(files),
            **options,
        )
        return await self.request(cast_to, opts)

    async def put(
        self,
        path: str,
        *,
        cast_to: Type[ResponseT],
        body: Body | None = None,
        content: AsyncBinaryTypes | None = None,
        files: RequestFiles | None = None,
        options: RequestOptions = {},
    ) -> ResponseT:
        if body is not None and content is not None:
            raise TypeError("Passing both `body` and `content` is not supported")
        if files is not None and content is not None:
            raise TypeError("Passing both `files` and `content` is not supported")
        opts = FinalRequestOptions.construct(
            method="put", url=path, json_data=body, content=content, files=await async_to_httpx_files(files), **options
        )
        return await self.request(cast_to, opts)

    async def delete(
        self,
        path: str,
        *,
        cast_to: Type[ResponseT],
        body: Body | None = None,
        content: AsyncBinaryTypes | None = None,
        options: RequestOptions = {},
    ) -> ResponseT:
        if body is not None and content is not None:
            raise TypeError("Passing both `body` and `content` is not supported")
        opts = FinalRequestOptions.construct(method="delete", url=path, json_data=body, content=content, **options)
        return await self.request(cast_to, opts)

    def get_api_list(
        self,
        path: str,
        *,
        model: Type[_T],
        page: Type[AsyncPageT],
        body: Body | None = None,
        options: RequestOptions = {},
        method: str = "get",
    ) -> AsyncPaginator[_T, AsyncPageT]:
        opts = FinalRequestOptions.construct(method=method, url=path, json_data=body, **options)
        return self._request_api_list(model, page, opts)


def make_request_options(
    *,
    query: Query | None = None,
    extra_headers: Headers | None = None,
    extra_query: Query | None = None,
    extra_body: Body | None = None,
    timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    post_parser: PostParser | NotGiven = not_given,
    qualifiers: dict[str, str] | None = None,
    span_name: str | None = None,
    span_route: str | None = None,
    span_content_query_params: Tuple[str, ...] = (),
    span_attributes: Mapping[str, AttributeValue] | Callable[[object], Mapping[str, AttributeValue]] | None = None,
    span_created_id: str | Tuple[str, str] | None = None,
) -> RequestOptions:
    """Create a dict of type RequestOptions without keys of NotGiven values."""
    options: RequestOptions = {}
    if extra_headers is not None:
        options["headers"] = extra_headers

    if extra_body is not None:
        options["extra_json"] = cast(AnyMapping, extra_body)

    if query is not None:
        options["params"] = strip_omit(query)

    if extra_query is not None:
        options["params"] = {**options.get("params", {}), **extra_query}

    if not isinstance(timeout, NotGiven):
        options["timeout"] = timeout

    if is_given(post_parser):
        # internal
        options["post_parser"] = post_parser  # type: ignore

    if qualifiers is not None:
        # internal
        options["qualifiers"] = qualifiers  # type: ignore

    if span_name is not None:
        # internal
        options["span_name"] = span_name  # type: ignore

    if span_route is not None:
        # internal
        options["span_route"] = span_route  # type: ignore

    if span_name is not None and query is not None:
        # internal: the names of the query parameters that the endpoint defines
        options["span_query_params"] = tuple(query)  # type: ignore

    if span_content_query_params:
        # internal: the query parameters that are content on this endpoint only
        options["span_content_query_params"] = span_content_query_params  # type: ignore

    if span_attributes is not None:
        # internal
        options["span_attributes"] = span_attributes  # type: ignore

    if span_created_id is not None:
        # internal
        options["span_created_id"] = span_created_id  # type: ignore

    return options


class ForceMultipartDict(Dict[str, None]):
    def __bool__(self) -> bool:
        return True


class OtherPlatform:
    def __init__(self, name: str) -> None:
        self.name = name

    @override
    def __str__(self) -> str:
        return f"Other:{self.name}"


Platform = Union[
    OtherPlatform,
    Literal[
        "MacOS",
        "Linux",
        "Windows",
        "FreeBSD",
        "OpenBSD",
        "iOS",
        "Android",
        "Unknown",
    ],
]


def get_platform() -> Platform:
    # NOTE: we deliberately avoid `platform.platform()` (and `platform.uname().processor`)
    # as they shell out to `uname -p`, which would fork the process on the first request.
    try:
        system = platform.system().lower()
        machine = platform.machine().lower()
        release = platform.release().lower()
    except Exception:
        return "Unknown"

    if system in ("ios", "ipados") or machine.startswith(("iphone", "ipad")):
        # CPython 3.13+ reports the system as iOS / iPadOS; older builds (e.g. Pythonista)
        # report Darwin with a machine like `iPhone12,1` / `iPad7,11`
        return "iOS"

    if system == "darwin":
        return "MacOS"

    if system == "windows":
        return "Windows"

    if system == "android" or hasattr(sys, "getandroidapilevel") or "android" in release:
        # CPython 3.13+ reports the system as Android; older builds (e.g. Pydroid 3) report
        # Linux with a release like `5.10.81-android12-9-00001-geba40aecb3b7-ab8534902`
        return "Android"

    if system == "linux":
        return "Linux"

    if system == "freebsd":
        return "FreeBSD"

    if system == "openbsd":
        return "OpenBSD"

    if system:
        return OtherPlatform(system)

    return "Unknown"


@lru_cache(maxsize=None)
def platform_headers(version: str, *, platform: Platform | None) -> Dict[str, str]:
    return {
        "X-Stainless-Lang": "python",
        "X-Stainless-Package-Version": version,
        "X-Stainless-OS": str(platform or get_platform()),
        "X-Stainless-Arch": str(get_architecture()),
        "X-Stainless-Runtime": get_python_runtime(),
        "X-Stainless-Runtime-Version": get_python_version(),
    }


class OtherArch:
    def __init__(self, name: str) -> None:
        self.name = name

    @override
    def __str__(self) -> str:
        return f"other:{self.name}"


Arch = Union[OtherArch, Literal["x32", "x64", "arm", "arm64", "unknown"]]


def get_python_runtime() -> str:
    try:
        return platform.python_implementation()
    except Exception:
        return "unknown"


def get_python_version() -> str:
    try:
        return platform.python_version()
    except Exception:
        return "unknown"


def get_architecture() -> Arch:
    try:
        machine = platform.machine().lower()
    except Exception:
        return "unknown"

    if machine in ("arm64", "aarch64"):
        return "arm64"

    # TODO: untested
    if machine == "arm":
        return "arm"

    if machine == "x86_64":
        return "x64"

    # TODO: untested
    if sys.maxsize <= 2**32:
        return "x32"

    if machine:
        return OtherArch(machine)

    return "unknown"


def _merge_mappings(
    obj1: Mapping[_T_co, Union[_T, Omit]],
    obj2: Mapping[_T_co, Union[_T, Omit]],
) -> Dict[_T_co, _T]:
    """Merge two mappings of the same type, removing any values that are instances of `Omit`.

    In cases with duplicate keys the second mapping takes precedence.
    """
    merged = {**obj1, **obj2}
    return {key: value for key, value in merged.items() if not isinstance(value, Omit)}


def _merge_extra_json(options: FinalRequestOptions) -> None:
    """Merge `extra_json` into `json_data` in place, as `_build_request` would.

    This runs before `_prepare_options` so that client hooks, such as Bedrock and Vertex
    routing, see `extra_body` values.
    """
    extra_json = options.extra_json
    if extra_json is None:
        return

    json_data = options.json_data
    if json_data is None:
        options.json_data = cast(Body, extra_json)
    elif is_mapping(json_data):
        options.json_data = _merge_mappings(json_data, extra_json)
    else:
        raise RuntimeError(f"Unexpected JSON data type, {type(json_data)}, cannot merge with `extra_body`")

    options.extra_json = None


# `x-stainless-helper` is the one header whose values accumulate across layers into a single
# comma-separated, deduplicated value instead of the later layer's value replacing the
# earlier one (hand-written, upstream to Stainless).
_APPEND_HEADERS = frozenset({"x-stainless-helper"})


def _append_header_value(existing: str, addition: str) -> str:
    """Append `addition` to a comma-separated header value, skipping tokens that
    are already present so the same helper isn't recorded twice.

    Values are joined with `", "`, the same format `lib._stainless_helpers` uses
    when it builds the `x-stainless-helper` header.
    """
    tokens = [token for token in (raw.strip() for raw in existing.split(",")) if token]
    for token in (raw.strip() for raw in addition.split(",")):
        if token and token not in tokens:
            tokens.append(token)
    return ", ".join(tokens)


def build_headers(*layers: Mapping[str, Union[str, Omit]]) -> tuple[httpx2.Headers, frozenset[str]]:
    """Fold header layers into one `httpx2.Headers`, later layers taking precedence whatever a name's casing.

    An `Omit` value removes the header set by an earlier layer; the second item holds the (lowercase)
    names removed that way and not set again by a later layer.
    """
    headers = httpx2.Headers(encoding="utf-8")
    omitted: set[str] = set()
    for layer in layers:
        for name, value in layer.items():
            if isinstance(value, Omit):
                headers.pop(name, None)
                omitted.add(name.lower())
            else:
                if name.lower() in _APPEND_HEADERS:
                    value = _append_header_value(headers.get(name, ""), value)
                headers[name] = value
                omitted.discard(name.lower())
    return headers, frozenset(omitted)


def merge_headers(*layers: Mapping[str, Union[str, Omit]]) -> Dict[str, str]:
    """Compose header layers into a single layer: a plain mapping, as `default_headers=` and
    `extra_headers=` accept, that still carries an `Omit` for every header the layers remove.

    The `Dict[str, str]` return type is the same fudge the rest of the header plumbing uses for
    `Omit`-bearing header mappings.
    """
    headers, omitted = build_headers(*layers)
    layer: Dict[str, Union[str, Omit]] = dict.fromkeys(omitted, omit)
    layer.update((name.decode("utf-8"), value.decode("utf-8")) for name, value in headers.raw)
    return cast("Dict[str, str]", layer)


def _middleware_entry_mode(request: APIRequest) -> Literal["raw", "stream"] | None:
    """The raw-response mode the original caller entered the middleware chain with."""
    headers = request.options.headers
    mode = headers.get(RAW_RESPONSE_HEADER) if is_given(headers) else None
    if isinstance(mode, str) and mode in ("raw", "stream"):
        # mypy for some reason cannot narrow the type
        return mode  # type: ignore
    return None


def _prepare_middleware_options(request: APIRequest) -> FinalRequestOptions:
    """Build the options the base middleware handler hands to `_attempt_request()`.

    Returns a copy so that mutations made by the request pipeline never leak back
    into the `APIRequest` between separate `call_next(...)` invocations, with the
    raw-response header set so that the pipeline produces an `APIResponse` /
    `AsyncAPIResponse` for the middleware chain.
    """
    options = model_copy(request.options)
    headers = dict(options.headers) if is_given(options.headers) else {}
    if headers.get(RAW_RESPONSE_HEADER) not in ("raw", "stream"):
        # plain calls (no raw-response header) are upgraded to "raw" so that the
        # middleware chain always operates on an `APIResponse` / `AsyncAPIResponse`;
        # the "stream" mode set by `.with_streaming_response` already produces one and
        # is left as-is so that the response body is not eagerly read.
        # `_finalize_middleware_result()` restores the value the original caller expects.
        headers[RAW_RESPONSE_HEADER] = "raw"
    options.headers = headers
    return options


def _expects_response_wrapper(cast_to: Any) -> bool:
    """Whether the given `cast_to` asks for the `APIResponse` wrapper itself."""
    origin = get_origin(cast_to) or cast_to
    return inspect.isclass(origin) and issubclass(origin, BaseAPIResponse)
